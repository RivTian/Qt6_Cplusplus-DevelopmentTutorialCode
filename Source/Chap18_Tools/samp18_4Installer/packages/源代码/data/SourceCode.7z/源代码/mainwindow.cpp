﻿#include "mainwindow.h"
#include "ui_mainwindow.h"

#include    <QFileDialog>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    player = new QMediaPlayer(this);
    QAudioOutput *audioOutput = new QAudioOutput(this);   //音频输出，指向默认的音频输出设备
    player->setAudioOutput(audioOutput);    //设置音频输出

    connect(player,&QMediaPlayer::positionChanged,      //播放位置发生变化
            this, &MainWindow::do_positionChanged);

    connect(player,&QMediaPlayer::durationChanged,      //播放源长度发生变化
            this, &MainWindow::do_durationChanged);

    connect(player, &QMediaPlayer::sourceChanged,       //播放源发生变化
            this, &MainWindow::do_sourceChanged);

    connect(player, &QMediaPlayer::playbackStateChanged,    //播放器状态发生变化
            this,  &MainWindow::do_stateChanged);

    connect(player, &QMediaPlayer::metaDataChanged,     //元数据发生变化
            this,  &MainWindow::do_metaDataChanged);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::do_stateChanged(QMediaPlayer::PlaybackState state)
{//播放器状态变化时执行，更新按钮状态，或播放下一曲
    ui->btnPlay->setEnabled(!(state==QMediaPlayer::PlayingState));
    ui->btnPause->setEnabled(state==QMediaPlayer::PlayingState);
    ui->btnStop->setEnabled(state==QMediaPlayer::PlayingState);

    //播放完一曲后停止了，如果loopPlay为true，自动播放下一曲
    if (loopPlay && (state ==QMediaPlayer::StoppedState))
    {
        int count=ui->listWidget->count();
        int curRow=ui->listWidget->currentRow();
        curRow++;
        curRow= curRow>=count? 0:curRow;
        ui->listWidget->setCurrentRow(curRow);
        player->setSource(playlist[curRow]);
        player->play();
    }
}

void MainWindow::do_sourceChanged(const QUrl &media)
{//播放的文件发生变化时的响应
    ui->labCurMedia->setText(media.fileName());
}

void MainWindow::do_durationChanged(qint64 duration)
{//播放源时长变化时执行，更新进度显示
    ui->sliderPosition->setMaximum(duration);

     int   secs=duration/1000;  //秒
     int   mins=secs/60;        //分钟
     secs=secs % 60;            //余数秒
     durationTime=QString::asprintf("%d:%d",mins,secs);
     ui->labRatio->setText(positionTime+"/"+durationTime);
}

void MainWindow::do_positionChanged(qint64 position)
{//播放位置变化时执行，更新进度显示
    if (ui->sliderPosition->isSliderDown())     //滑条正被鼠标拖动
        return;

    ui->sliderPosition->setSliderPosition(position);
    int   secs=position/1000;   //秒
    int   mins=secs/60;         //分钟
    secs=secs % 60;             //余数秒
    positionTime=QString::asprintf("%d:%d",mins,secs);
    ui->labRatio->setText(positionTime+"/"+durationTime);
}

void MainWindow::do_metaDataChanged()
{//元数据变化时执行，显示歌曲图片
    QMediaMetaData metaData=player->metaData();     //元数据对象
    QVariant  metaImg= metaData.value(QMediaMetaData::ThumbnailImage);  //获取ThumbnailImage元数据
    if (metaImg.isValid())
    {
        QImage img= metaImg.value<QImage>();        //QVariant转换为QImage
        QPixmap musicPixmp= QPixmap::fromImage(img);
        if (ui->scrollArea->width() <musicPixmp.width())
            ui->labPic->setPixmap(musicPixmp.scaledToWidth(ui->scrollArea->width()-30));
        else
            ui->labPic->setPixmap(musicPixmp);
    }
    else
        ui->labPic->clear();
}

void MainWindow::on_btnAdd_clicked()
{//"添加"按钮，添加文件，构建播放媒介列表
     QString curPath=QDir::homePath();  //获取系统当前目录
     QString dlgTitle="选择音频文件";
     QString filter="音频文件(*.mp3 *.wav *.wma);;所有文件(*.*)"; //文件过滤器
     QStringList fileList=QFileDialog::getOpenFileNames(this,dlgTitle,curPath,filter);
     if (fileList.count()<1)
         return;

     for (int i=0; i<fileList.size();i++)
     {
        QString aFile=fileList.at(i);
        playlist.append(QUrl::fromLocalFile(aFile));    //添加文件到播放列表
        QFileInfo   fileInfo(aFile);
        ui->listWidget->addItem(fileInfo.fileName());   //添加到界面上的文件列表
     }

     if (player->playbackState() != QMediaPlayer::PlayingState)
     {  //当前没有在播放，就播放第1个文件
         ui->listWidget->setCurrentRow(0);
         player->setSource(playlist[0]);
     }
     player->play();
}

void MainWindow::on_btnPlay_clicked()
{//开始播放
    if (ui->listWidget->currentRow()<0)
    {//没有选择文件，就播放第1个
        ui->listWidget->setCurrentRow(0);
        player->setSource(playlist[0]);
    }
    loopPlay=ui->btnLoop->isChecked();  //是否循环播放
    player->play();
}

void MainWindow::on_btnPause_clicked()
{//暂停播放
    player->pause();
}

void MainWindow::on_btnStop_clicked()
{//停止播放
    loopPlay=false;
    player->stop();
}

void MainWindow::on_listWidget_doubleClicked(const QModelIndex &index)
{//双击时切换播放文件
    int rowNo=index.row();
    if(ui->btnLoop->isChecked())
    {
        loopPlay=false;     //暂时设置为false，防止do_stateChanged()里切换曲目
        player->setSource(playlist[rowNo]);
        player->play();
        loopPlay=true;
    }
}

void MainWindow::on_btnClear_clicked()
{//"清空"按钮，清空播放列表
    playlist.clear();
    ui->listWidget->clear();
    player->stop();
}

void MainWindow::on_sliderVolumn_valueChanged(int value)
{//调整音量
    player->audioOutput()->setVolume(value/100.0);        //0~ 1之间
}

void MainWindow::on_btnSound_clicked()
{//静音控制
    bool mute=player->audioOutput()->isMuted();
    player->audioOutput()->setMuted(!mute);
    if (mute)
        ui->btnSound->setIcon(QIcon(":/images/images/volumn.bmp"));
    else
        ui->btnSound->setIcon(QIcon(":/images/images/mute.bmp"));
}

void MainWindow::on_sliderPosition_valueChanged(int value)
{//播放进度调控
   player->setPosition(value);
}

void MainWindow::on_btnPrevious_clicked()
{//前一曲
    int curRow=ui->listWidget->currentRow();
    curRow--;
    curRow= curRow<0? 0:curRow;
    ui->listWidget->setCurrentRow(curRow);  //设置当前行

    if(ui->btnLoop->isChecked())
    {
        loopPlay=false;     //暂时设置为false，防止do_stateChanged()里切换曲目
        player->setSource(playlist[curRow]);
        player->play();
        loopPlay=true;
    }
}

void MainWindow::on_btnNext_clicked()
{//下一曲
    int count=ui->listWidget->count();
    int curRow=ui->listWidget->currentRow();
    curRow++;
    curRow= curRow>=count? count-1:curRow;
    ui->listWidget->setCurrentRow(curRow);

    if(ui->btnLoop->isChecked())
    {
        loopPlay=false;     //暂时设置为false，防止do_stateChanged()里切换曲目
        player->setSource(playlist[curRow]);
        player->play();
        loopPlay=true;
    }
}

void MainWindow::on_btnLoop_clicked(bool checked)
{//"循环" Checkbox
    loopPlay=checked;
}

void MainWindow::on_doubleSpinBox_valueChanged(double arg1)
{//"倍速" DoubleSpinbox
    player->setPlaybackRate(arg1);
}

